    <!-- jQuery -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <!-- Popper.js -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"
        integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
        crossorigin="anonymous"></script>
    <!-- Bootstrap JS -->
    <script src="bootstrap-4.1.1-dist/js/bootstrap.min.js"></script>
    <!-- Icons -->
    <script src="https://cdn.jsdelivr.net/npm/vivid-icons"></script>
    <script src="https://unpkg.com/vivid-icons"></script>
    <!-- OWL Carousel -->
    <script src="js/plugins/owl-carousel/owl.carousel.js"></script>
    <!-- Video Pop Up Plugin -->
    <script src="js/plugins/YouTube_PopUp-master/YouTubePopUp.jquery.js"></script>
    <script src="js/plugins/wow/wow.min.js"></script>
    <!-- Easing -->
    <script src="js/plugins/jquery.easing.min.js"></script>
    <!-- Main JS -->
    <script src="js/main.js"></script>
