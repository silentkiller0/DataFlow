    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="bootstrap-4.1.1-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css"
        integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
    <!-- OWl Carousel CSS Files -->
    <link rel="stylesheet" href="js/plugins/owl-carousel/owl.carousel.css">
    <link rel="stylesheet" href="js/plugins/owl-carousel/owl.theme.css">
    <link rel="stylesheet" href="js/plugins/owl-carousel/owl.transitions.css">
    <!-- ANIMATE CSS -->
    <link rel="stylesheet" href="css/animate.css">
    <!-- Video Pop Up Plugin -->
    <link rel="stylesheet" href="js/plugins/YouTube_PopUp-master/YouTubePopUp.css">
    <!-- PRELOADER -->
    <link rel="stylesheet" href="css/preloader.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js"
        type="text/javascript"></script>
    <link rel="stylesheet" href="css/load.css">


    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">


    <!-- Main CSS -->
    <link rel="stylesheet" href="css/style.css">