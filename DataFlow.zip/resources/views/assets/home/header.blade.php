<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" href="app-assets/images/ico/Dataflow_icone.ico" type="image/x-icon" />
    <title>DataFlow - Votre compagnon d'affaires quotidien</title>
    @include('assets.home.css')

</head>