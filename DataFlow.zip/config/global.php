<?php

return [

    'APP_KEY' => null,
]

?>